let ProductData = [
    {
        id: 1,
        name: "Product 01",
        price: 200,
        Description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae sed minima commodi, fugiat deserunt iste consectetur'
    },
    {
        id: 2,
        name: "Product 02",
        price: 349,
        Description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae sed minima commodi, fugiat deserunt iste consectetur'
    },
    {
        id: 3,
        name: "Product 03",
        price: 499,
        Description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae sed minima commodi, fugiat deserunt iste consectetur'
    }
]

export default ProductData;