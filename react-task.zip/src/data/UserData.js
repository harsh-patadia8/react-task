let UserData = [
    {
        id: 1,
        username: "Admin 01",
        email:"admin@admin.com",
        role: 1, //["0=>user", "1=>admin"]
        cartItems: [],
        password: '1234'
    },
    {
        id: 2,
        username: "user 02",
        email:"user@user.com",
        role: 0,
        cartItems: [],
        password: '1234'
    }
]


export default UserData;